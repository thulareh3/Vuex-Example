<template>
  <div id="app">
    <Customer/>
 </div>
</template>
<script>
import Customer from './components/Customer.vue';


  export default {
    components : {
      Customer
    }
  }
</script>
<style>
  #app {
    font-family: 'Avenir', Helvetica, Arial, sans-serif;
  }
</style>